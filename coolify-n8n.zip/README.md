# Coolify n8n with Puppeteer + Chromium

Deploy n8n on Coolify with full Puppeteer/Chromium support.

## Files
- Dockerfile
- docker-compose.yml
- .env.example

## How to Deploy
1. Fork this repository
2. Connect to Coolify
3. Deploy using docker-compose.yml
4. Set environment variables
5. Redeploy
